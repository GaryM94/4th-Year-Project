﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;
using System.Globalization;

namespace Messenger.Models
{
    public class Messages
    {
        public int MessageID{ get; set; }
        public string sender { get; set; }
        public string reciever { get; set; }
        public string content { get; set; }
    }
}